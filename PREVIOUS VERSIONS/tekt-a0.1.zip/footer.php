<html>
<body>
<div id="footer">
<h1>TAICHI AND ARY
  A COPYRIGHTED THIS SHIT SO DONT STEAL IT</h1>
</div>
</body>
</html>
