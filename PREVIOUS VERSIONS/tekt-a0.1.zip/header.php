<html>
<head>
<title>alpha 1</title>
<link rel="stylesheet" href="<?php bloginfo('style.css'); ?>">
</head>
<body>
<div id="wrapper">
<div id="header">
<h1>HEADER</h1>
</div>
/*This is the beginning of the actual class which will contain the
parts of the website that we have to create, it is referenced in
the style.css code*/
