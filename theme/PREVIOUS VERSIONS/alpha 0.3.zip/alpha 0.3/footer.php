<!doctype html>

<html>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url')?>"/>

<div id="footer">
<footer>
  &copy; <?php echo date("Y"); ?> Copyright never;
</footer>
</div>
</html>
