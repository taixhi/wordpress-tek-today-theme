
<!doctype html>
<?php get_header()?>

<div>
  <link rel="stylesheet" href="<?php bloginfo('stylesheet_url')?>"/>

    <p>'This is a p thingy'</p>
</div>

<?php get_footer()?>
<?php get_sidebar()?>
