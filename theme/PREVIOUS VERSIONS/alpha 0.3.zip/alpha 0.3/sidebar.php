<!doctype html>

<html>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url')?>"/>

<div id="sidebar">

  <h1>This is a sidebar</h1>

</div>
</html>
