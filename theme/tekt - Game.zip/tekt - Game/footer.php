<!doctype html>
<html>
</div>

<div id="footer">
<div id="copyright">
<footer>
<p><?php echo comicpress_copyright();?>
  <a><strong>tek</strong>today. All rights reserved.</a>
  <p id="meher"> Designed by Meher Vohra</p>
  <p id="theme_cr">Theme by Arya Vohra and Taichi Kato</p>

</p>
</footer>
</div>

</div>

</html>
