
	<div id="sidebar">
			<ul class="xoxo" style=".widget{float:none!important};">
        <?php dynamic_sidebar( 'right_sidebar' ); ?>
			</ul>
		</div><!-- #secondary .widget-area -->
